import { base44 } from './base44Client';


export const StudentProfile = base44.entities.StudentProfile;

export const Roadmap = base44.entities.Roadmap;



// auth sdk:
export const User = base44.auth;